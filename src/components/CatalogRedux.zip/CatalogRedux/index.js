import {useContext} from 'react';
import {useSelector, useDispatch} from 'react-redux';
import CardHooks from '../CardHooks';

import {AuthContext} from '../../AuthContext';
import {DELETE_CAR} from '../../store/actions/catalog-actions';

function CatalogRedux (props) {

    let dispatch = useDispatch();
    const {user} = useContext(AuthContext);
    let cars = useSelector((state) => state.catalog);

    const deleteCar = (car) => {
        dispatch({
            type: DELETE_CAR,
            payload: car
        });
    }

    return (
        <>
            <div className="list">
                {cars.map((car) => (
                    <div key={car.id}>
                        <CardHooks data={car}>
                            { user && <button onClick={() => deleteCar(car)}>Удалить</button> }
                        </CardHooks>
                    </div>
                ))}
            </div>
        </>
    )
}

export default CatalogRedux;